%% In this code, we apply data augmentation-based sparse Bayesian learning method 
%%% to identify the homogeneous diffusion in  a double well potential



%% The homogeneous diffusion in  a double well potential 
%%%%  dx=(a*x^3+b*x^2+c*x+d)*dt+e*dW

clc
clear
close all

%%  Euler-Maruyama discretization 

randn('state',100)
n=1200;  
dt=0.001;x(1)=1;a=0.3;
 for i=1:n/dt
     x(i+1)=x(i)-(x(i)^3-x(i))*dt+a*sqrt(dt)*randn;
 end
 Dt=0.3; %% Dt  statisfies Dt=n*dt, where n is a integer.
 X=x(1:Dt/dt:end);
 
 %% Plot
plot(x)
figure('color',[1 1 1]);
plot(0:dt:n,x,'Linewidth',1.2)
hold on
plot(0:Dt:n,X,'r.','Markersize',5)
set(gca,'ytick',-1.5:1:1.5,'fontSize',15,'linewidth',0.8)
xlabel('$t$','interpreter','latex','fontsize',24)
ylabel('$x(t)$','interpreter','latex','fontsize',24)

%% Basis functions


 Z=X';
 u=Z(1:end-1);
fx=[ones(size(u,1),1),u,u.^2,u.^3,u.^4,u.^5];
fx_name={'1','u','u^2','u^3','u^4','u^5'};


 %% MCMC sampler
 hp=1;dtt=Dt/(hp+1); T1=0:Dt:n; %hp denotes the number of latent states;
 Phi={'1','x','x^2','x^3','x^4','x^5'};
 
 tic
 [sies,thes,X,X_P,X2_P,th_P,ga_P,si_P,XAR,XAR_rate,Rv]=GibbsSampler(Z',T1,dtt,hp,Phi);
 toc
 
 %% Identification Result
 
threshold = 0.03;
y_name = 'b(x(t))';
fprintf('%s = ', y_name);
W2=th_P;
for i = 1:size(W2,2)
    if abs(W2(i))<threshold
       ;
    else
       if W2(i)<0
           fprintf('%.4f%s', W2(i),fx_name{i});        
       else
           fprintf('+');
           fprintf('%.4f%s', W2(i),fx_name{i});
        end
    end
end
fprintf('\n')
 

%%  MH-within-PCG sampler
 
 function [sies,thes,X,X_P,X2_P,th_P,ga_P,si_P,XAR,XAR_rate,Rv]=GibbsSampler(Z,T1,dt,hp,Phi)  %x column vector    t row vector
        %% Illustration
        %%% Z: p*(n+1)  p denotes the dimension of SDEs and (n+1) is the
        %%%  total number of measurements
        %%% T1: 1*(n+1) 
        %%% dt: The finer time step
        %%% hp: The number of hidden states
        %%% Phi: The selected basis functions 
    
        

%% Initialization
        Phi=[];
        a=1e-4;b=1e-4;MI=40000;ep=0.1;% ep denotes the step size
        T=[T1(1):dt:T1(end)];
        n = length(T1)-1;N = length(T)-1;                                   
        t_ind = ismembertol(T,T1); % For example: t_ind=[1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1]
        t_ind1 = find(t_ind); % For example: [1 5 9 13]
        t_ind2 = find(t_ind==0);
        p=size(Z,1); 
        XX =interp1(T1',Z',T','linear')';%p*(N+1)
        X2(:,:,1)=XX(:,t_ind2);% p*(hp*n)
        X(:,t_ind1,1)=Z;
        X(:,t_ind2,1)=X2(:,:,1);
        OX=X(:,2:end,1);UX=X(:,1:end-1,1);dX=OX-UX;% p*N
        Phi=PhiBF(UX); % q*N
        q=size(Phi,1);% q denotes the number of basis functions; 
         si(:,1)=ones(p,1);ga(:,:,1)=0.1*ones(p,q);th(:,:,1)=ones(p,q);
        XAR=0;
        %% Formulas  that  we don't need to calculate in each iteration 
        cof=1:hp;cof=cof/(hp+1); cof=repmat(cof,1,n); cof=diag(cof); %np*np
        for i=1:hp
          for j=i:hp
            P(i,j)=i*(hp+1-j)/(hp+1);
          end
        end
        P=P+P'-diag(diag(P));
        L=chol(P)';
        mc=Z(:,2:end)-Z(:,1:end-1);
        mcp=kron(mc,ones(1,hp))*cof; 
        m2=kron(Z(:,1:end-1),ones(1,hp))+mcp;
       %% Iterations
         for i=1:MI
             if mod(i,500)==0;
                 fprintf('Iteration: %d \n',i)
             end            
     %% Sample X(T2)
         for ii=1:p           
               for jj=1:n
                   e1=m2(ii,(jj-1)*hp+1:jj*hp);
                   e2=X2(ii,(jj-1)*hp+1:jj*hp,i)-e1;
                   X2(ii,(jj-1)*hp+1:jj*hp,i+1) = (e1'+sqrt(1-ep^2)*e2'+ep*sqrt(si(ii,i)*dt)*L*randn(hp,1))';
               end
         end
         
     
      %% Formulate acceptance probability.
      
      Xk(:,t_ind1,i)=Z;Xk(:,t_ind2,i)=X2(:,:,i);
      OX=Xk(:,2:end,i);UX=Xk(:,1:end-1,i);dxk=OX-UX;
      Phik=PhiBF(UX);
 
      Xp(:,t_ind1,i)=Z;Xp(:,t_ind2,i)=X2(:,:,i+1);
      OX=Xp(:,2:end,i);UX=Xp(:,1:end-1,i);dxp=OX-UX; 
      Phip=PhiBF(UX);     
      R=1;
      
      for jj=1:p
          K1=diag((1./ga(jj,:,i)))*si(jj,i)+dt*Phip*Phip';
          [U1,S1,V1]=svd(K1);
          K2=diag((1./ga(jj,:,i)))*si(jj,i)+dt*Phik*Phik';
          [U2,S2,V2]=svd(K2);
          r1=(det(S2)/det(S1))^(0.5);
          
          KK1=dxp(jj,:)*Phip'*U1;
          KK2=dxk(jj,:)*Phik'*U2;
          
          ga(jj,:,i);
          cc1= KK1*diag(1./diag(S1))*KK1';
          cc2=KK2*diag(1./diag(S2))*KK2';
   
          
          r2=exp(1/(2*si(jj,i))*(KK1*diag(1./diag(S1))*KK1'-KK2*diag(1./diag(S2))*KK2'));
          % Another choice
% % % % % %           KK1=dxp(jj,:)*Phip'*inv(K1)*Phip*dxp(jj,:)';
% % % % % %           KK2=dxk(jj,:)*Phik'*inv(K2)*Phik*dxk(jj,:)';
% % % % % %           r2=exp(1/(2*si(jj,i))*(KK1-KK2))
          R=R*r1*r2;  
      end
      Rv(i)=R;

           acc=rand;
           
        if acc<= min(1,R)
            X2(:,:,i+1)=X2(:,:,i+1);
            XAR=XAR+1;
         
        else
            X2(:,:,i+1)= X2(:,:,i);    
          
        end
       
% % % % % % % % % %% Formulate acceptance probability
% % % % % % % % %          for jj=1:p
% % % % % % % % %              r1=det(diag(si(jj,i)*(1./ga(jj,:,i)))+dt*Phip*Phip')^(-0.5)*exp(1/(2*si(jj,i))*dxp(jj,:)*Phip'*inv(si(jj,i)*diag(1./ga(jj,:,i))+dt*Phip*Phip')*Phip*dxp(jj,:)');
% % % % % % % % %              r2=det(diag(si(jj,i)*(1./ga(jj,:,i)))+dt*Phik*Phik')^(-0.5)*exp(1/(2*si(jj,i))*dxk(jj,:)*Phik'*inv(si(jj,i)*diag(1./ga(jj,:,i))+dt*Phik*Phik')*Phik*dxk(jj,:)');
% % % % % % % % %              R=R*r1/r2
% % % % % % % % %          end
% % % % % % % % %       

         X(:,t_ind1,i+1)=Z;X(:,t_ind2,i+1)=X2(:,:,i+1);
   
         OX=X(:,2:end,i+1);UX=X(:,1:end-1,i+1);
         dx=OX-UX; 
         Phi=PhiBF(UX);
     
         
      %% Sample theta
        for  jj=1:p
             Ar=pinv(dt*Phi*Phi'/si(jj,i)+diag(1./ga(jj,:,i)));%\eye(q);
             OHr=1/si(jj,i)*dx(jj,:)*Phi'*Ar;
             Lth=chol(Ar)';
             th(jj,:,i+1)=(OHr'+Lth*randn(q,1))';
        end
        
         
                   
      %% sample gamma     
                      for ii=1:p
                          for jj=1:q
                              
                              ga(ii,jj,i+1)=sampig(a+0.5,b+0.5*th(ii,jj,i+1)^2);
                          end
                         
                      end
       %% sample sigma
       for jj=1:p
                   sishape=a+N/2;
                   err2(jj)=sum((dx(jj,:)-(th(jj,:,i+1)*Phi*dt)).^2);
                   siscale=b+err2(jj)/(2*dt);
                   si(jj,i+1)=sampig(sishape,siscale);
       end
    
         end
      sies=si;
      thes=th;
  
      %%  Infer mode of each random variable
   X2_P=zeros(p,hp*n);X_P=zeros(p,N+1); si_P=zeros(p,1);ga_P=zeros(p,q);th_P=zeros(p,q);
            for jj=MI/2:MI
                X2_P=X2_P+X2(:,:,jj);
                X_P=X_P+X(:,:,jj);
                th_P=th_P+th(:,:,jj);
                ga_P=ga_P+ga(:,:,jj);
                si_P=si_P+si(:,jj);
            end
            
            IMP=MI/2+1;
            X2_P=X2_P/IMP;
            X_P=X_P/IMP;
            th_P=th_P/IMP;
            ga_P=ga_P/IMP;
            si_P=si_P/IMP; 
            XAR_rate = XAR/MI;
end
         
%%  Sample inverse gamma distribution
   function IG=sampig(x,y)
                  IGG=gamrnd(x,1/y);
                  IG=1/IGG;
   end
%% Formulate library matrix
function phi=PhiBF(X)
        ss=size(X,2);     
phi=[ones(1,ss);X;X.^2;X.^3;X.^4;X.^5];
end




