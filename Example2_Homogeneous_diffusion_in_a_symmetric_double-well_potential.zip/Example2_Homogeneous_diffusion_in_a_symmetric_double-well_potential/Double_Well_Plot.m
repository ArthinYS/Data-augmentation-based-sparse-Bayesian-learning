clear
clc
close all
load ('Double_Well_Potential.mat')

for i=1:6
    a(i,:)= thes(1,i,20001:end);
end

%figure('color',[1 1 1]);

numbin=70;
    subplot(2,3,1)
    histogram(a(1,:),numbin,'Normalization','pdf')
  % histogram(a(1,:),80,'Normalization','pdf')
    title('1')
    %xlabel('\theta_{11}')
    xlabel('${\theta_1}$','interpreter','latex','fontSize',100)
    ylabel('PDF') 
    set(gca,'fontSize',13,'linewidth',0.8)
    set(gcf,'unit','normalized','position',[0.2,0.2,0.64,0.32])
    %set(gca,'fontSize',4)
    
    


  subplot(2,3,2)
    histogram(a(2,:),numbin,'Normalization','pdf')
    title('x')
    xlabel('$\theta_2$','interpreter','latex','fontSize',14)
 %   ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
      subplot(2,3,3)
    histogram(a(3,:),numbin,'Normalization','pdf')
    title('x^2')
    xlabel('$\theta_3$','interpreter','latex','fontSize',14)
%    ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
      subplot(2,3,4)
    histogram(a(4,:),numbin,'Normalization','pdf')
    title('x^3')
    xlabel('$\theta_4$','interpreter','latex','fontSize',14)
    ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
    subplot(2,3,5)
    histogram(a(5,:),numbin,'Normalization','pdf')
    title('x^4')
    xlabel('$\theta_5$','interpreter','latex','fontSize',14)
  %  ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
         subplot(2,3,6)
    histogram(a(6,:),numbin,'Normalization','pdf')
    title('x^5')
    xlabel('$\theta_6$','interpreter','latex','fontSize',14)
  %  ylabel('PDF') 
    set(gca,'fontSize',13,'linewidth',0.8) 
    
 % print('Langevin','-depsc')
  
    