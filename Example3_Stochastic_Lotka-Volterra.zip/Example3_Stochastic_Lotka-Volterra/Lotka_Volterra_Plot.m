clear
clc
close all
load ('Stochastic_Lotka_Volterra.mat')

for i=1:6
    a(i,:)= thes(1,i,20001:end);
end

for i=7:12
    a(i,:)= thes(2,i-6,20001:end);
end


%figure('color',[1 1 1]);

numbin=70;

for i=1
    subplot(2,3,1)
    histogram(a(1,:),numbin,'Normalization','pdf')
  % histogram(a(1,:),80,'Normalization','pdf')
    title('1')
    %xlabel('\theta_{11}')
    xlabel('$\theta_{11}$','interpreter','latex','fontSize',100)
    ylabel('PDF') 
    set(gca,'fontSize',13,'linewidth',0.8)
    set(gcf,'unit','normalized','position',[0.2,0.2,0.64,0.32])
    %set(gca,'fontSize',4)
    
    


  subplot(2,3,2)
    histogram(a(2,:),numbin,'Normalization','pdf')
    title('x')
    xlabel('$\theta_{12}$','interpreter','latex','fontSize',14)
  %  ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
      subplot(2,3,3)
    histogram(a(3,:),numbin,'Normalization','pdf')
    title('y')
    xlabel('$\theta_{13}$','interpreter','latex','fontSize',14)
  %  ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
      subplot(2,3,4)
    histogram(a(4,:),numbin,'Normalization','pdf')
    title('x^2')
    xlabel('$\theta_{14}$','interpreter','latex','fontSize',14)
    ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
    subplot(2,3,5)
    histogram(a(5,:),numbin,'Normalization','pdf')
    title('xy')
    xlabel('$\theta_{15}$','interpreter','latex','fontSize',14)
  %  ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
         subplot(2,3,6)
    histogram(a(6,:),numbin,'Normalization','pdf')
    title('y^2')
    xlabel('$\theta_{16}$','interpreter','latex','fontSize',14)
  %  ylabel('PDF') 
    set(gca,'fontSize',13,'linewidth',0.8) 
    
 % print('Langevin','-depsc')
end

for i=1
 
 subplot(2,3,1)
    histogram(a(7,:),numbin,'Normalization','pdf')
  % histogram(a(1,:),80,'Normalization','pdf')
    title('1')
    %xlabel('\theta_{11}')
    xlabel('$\theta_{21}$','interpreter','latex','fontSize',100)
    ylabel('PDF') 
    set(gca,'fontSize',13,'linewidth',0.8)
    set(gcf,'unit','normalized','position',[0.2,0.2,0.64,0.32])
    %set(gca,'fontSize',4)
    
    


  subplot(2,3,2)
    histogram(a(8,:),numbin,'Normalization','pdf')
    title('x')
    xlabel('$\theta_{22}$','interpreter','latex','fontSize',14)
  %  ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
      subplot(2,3,3)
    histogram(a(9,:),numbin,'Normalization','pdf')
    title('y')
    xlabel('$\theta_{23}$','interpreter','latex','fontSize',14)
 %   ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
      subplot(2,3,4)
    histogram(a(10,:),numbin,'Normalization','pdf')
    title('x^2')
    xlabel('$\theta_{24}$','interpreter','latex','fontSize',14)
    ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
    subplot(2,3,5)
    histogram(a(11,:),numbin,'Normalization','pdf')
    title('xy')
    xlabel('$\theta_{25}$','interpreter','latex','fontSize',14)
  %  ylabel('PDF') 
     set(gca,'fontSize',13,'linewidth',0.8) 
    
         subplot(2,3,6)
    histogram(a(12,:),numbin,'Normalization','pdf')
    title('y^2')
    xlabel('$\theta_{26}$','interpreter','latex','fontSize',14)
   % ylabel('PDF') 
    set(gca,'fontSize',13,'linewidth',0.8) 
end
    